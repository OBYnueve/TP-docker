<?php

echo "salut"

?>
